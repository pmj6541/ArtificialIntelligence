from pathlib import Path

CSV = Path("./csv/")
RESULT = Path("./results/")
IMG = Path("./img/")
