import tree_search
import dist

sol = tree_search.getTreeSolution()

cost = dist.total_cost(sol)
print("total_cost : ",cost)








