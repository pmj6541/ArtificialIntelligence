from randomsearch import RandomSearch

rand_search = RandomSearch()
rand_search.run()
rand_search.save()
